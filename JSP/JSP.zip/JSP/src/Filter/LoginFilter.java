package Filter;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionContext;
import java.io.IOException;
import java.util.Enumeration;

/**
 * @Author:XiaoYang01
 * @Date: 2021/3/4 14:33 @Week: 星期四
 * Package: JavaSE
 */
public class LoginFilter implements Filter {

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        //强转为HttpServletRequest
        HttpServletRequest req = (HttpServletRequest) servletRequest;
        //获取uri
        String uri = req.getRequestURI();
        //对首页放行
        if(uri.equals("/myWeb/")){
            filterChain.doFilter(servletRequest,servletResponse);
            return;
        }

        //对注册放行
        if(uri.equals("/myWeb/html/LoginRegister.html")){
            filterChain.doFilter(servletRequest,servletResponse);
            return;
        }

        //对登录放行
        if(uri.indexOf("login") != -1 || uri.indexOf("Login") != -1){
            filterChain.doFilter(servletRequest,servletResponse);
            return;
        }

        //对静态文件放行放行
        if(uri.indexOf("img") != -1 || uri.indexOf("css") != -1 || uri.indexOf("js") != -1){
            filterChain.doFilter(servletRequest,servletResponse);
            return;
        }

        //对非法进行拦截
        HttpSession session = req.getSession(false);
        if(session == null){
            req.getRequestDispatcher("/error/404.html").forward(servletRequest,servletResponse);
            return;
        }
        filterChain.doFilter(servletRequest,servletResponse);
    }
}
