package userSystem;

/**
 * @Author:XiaoYang01
 * @Date: 2021/3/4 16:32 @Week: 星期四
 * Package: JavaSE
 */
public class User {
    //姓名
    private String userName;
    //密码
    private String userPassword;

    //构造器
    public User(String userName, String userPassword) {
        this.userName = userName;
        this.userPassword = userPassword;
    }

    public User() {
    }

    //set/get
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }
}
