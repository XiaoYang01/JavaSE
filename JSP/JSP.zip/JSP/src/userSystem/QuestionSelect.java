package userSystem;

import util.MysqlConnect;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

/**
 * @Author:XiaoYang01
 * @Date: 2021/3/6 14:23 @Week: 星期六
 * Package: JavaSE
 */
public class QuestionSelect extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //JDBC
        MysqlConnect connect = new MysqlConnect();

        //试题select
        Map map = (Map) connect.questionSelect();

        //判断与跳转
        if(map != null){
            req.setAttribute("map",map);
            req.getRequestDispatcher("/JSP/QuestionSelect.jsp").forward(req,resp);
            return;
        }else{
            req.getRequestDispatcher("/error/404.html").forward(req,resp);
            return;
        }
    }
}
