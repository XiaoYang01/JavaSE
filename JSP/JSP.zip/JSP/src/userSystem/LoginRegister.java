package userSystem;

import util.MysqlConnect;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.Arrays;

/**
 * @Author:XiaoYang01
 * @Date: 2021/3/5 8:24 @Week: 星期五
 * Package: JavaSE
 */
public class LoginRegister extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取传参
        String userName = req.getParameter("userName");
        String userPassword = req.getParameter("userPassword");
        System.out.println(userName);
        //创建User对象
        User user = new User(userName, userPassword);

        //JDBC
        MysqlConnect connect = new MysqlConnect();

        //注册
        int count = 0;
        count = connect.register(user);

        //判断
        if (count != 0) {
            //把结果写入到全局作用域中
            req.setAttribute("into","注册成功");
        } else {
            req.setAttribute("into","注册失败");
        }

        //传递给JSP
        req.getRequestDispatcher("/JSP/doRegister.jsp").forward(req,resp);
    }
}
