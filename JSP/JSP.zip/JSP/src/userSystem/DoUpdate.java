package userSystem;

import util.MysqlConnect;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @Author:XiaoYang01
 * @Date: 2021/3/6 16:42 @Week: 星期六
 * Package: JavaSE
 */
public class DoUpdate extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取传参
        Integer id = Integer.valueOf(req.getParameter("id"));
        String title = req.getParameter("title");
        String questionA = req.getParameter("questionA");
        String questionB = req.getParameter("questionB");
        String questionC = req.getParameter("questionC");
        String questionD = req.getParameter("questionD");
        String correct = req.getParameter("correct");

        //Questions对象创建
        Questions questions = new Questions(id,title,questionA,questionB,questionC,questionD,correct);

        //JDBC
        MysqlConnect connect = new MysqlConnect();

        //接受，判断
        int count = connect.doUpdate(questions);

        if (count != 0){
            req.setAttribute("update","修改成功");
        }else{
            req.setAttribute("update","修改失败");
        }
        req.getRequestDispatcher("/JSP/DoUpdate.jsp").forward(req,resp);
    }
}
