package userSystem;

import util.MysqlConnect;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @Author:XiaoYang01
 * @Date: 2021/3/6 19:11 @Week: 星期六
 * Package: JavaSE
 */
public class UserUpdate extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取ID
        Integer id = Integer.valueOf(req.getParameter("id"));

        //JDBC
        MysqlConnect connect = new MysqlConnect();

        //传参
        DoUser doUser = connect.userSelect(id);

        //判断
        if(doUser != null){
            req.setAttribute("id",doUser);
            req.getRequestDispatcher("/JSP/UserUpdate.jsp").forward(req,resp);
            return;
        }else{
            req.getRequestDispatcher("/error/404.html").forward(req,resp);
            return;
        }
    }
}
