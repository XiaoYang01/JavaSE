package userSystem;
import util.MysqlConnect;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * @Author:XiaoYang01
 * @Date: 2021/3/4 16:24 @Week: 星期四
 * Package: JavaSE
 */
public class Login extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取传参
        String userName = req.getParameter("userName");
        String userPassword = req.getParameter("userPassword");
        //创建User对象
        User user = new User(userName,userPassword);
        //创建JDBC连接工具
        MysqlConnect connect = new MysqlConnect();
        //传参连接
        boolean result = connect.login(user);
        if(result){
            //创建Session
            HttpSession session = req.getSession();
            //重定向
            req.getRequestDispatcher("/html/Navigation.html").forward(req,resp);
        }else{
            req.getRequestDispatcher("/error/404.html").forward(req,resp);
        }
    }
}
