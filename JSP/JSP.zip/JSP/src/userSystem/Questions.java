package userSystem;

/**
 * @Author:XiaoYang01
 * @Date: 2021/3/6 12:15 @Week: 星期六
 * Package: JavaSE
 */
public class Questions {
    //参数属性
    private Integer Id;
    private String title;
    private String questionA;
    private String questionB;
    private String questionC;
    private String questionD;
    private String correct;

    //构造器
    public Questions() {
    }

    public Questions(Integer id, String title, String questionA, String questionB, String questionC, String questionD, String correct) {
        Id = id;
        this.title = title;
        this.questionA = questionA;
        this.questionB = questionB;
        this.questionC = questionC;
        this.questionD = questionD;
        this.correct = correct;
    }

    //set/get
    public Integer getId() {
        return Id;
    }

    public void setId(Integer id) {
        Id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getQuestionA() {
        return questionA;
    }

    public void setQuestionA(String questionA) {
        this.questionA = questionA;
    }

    public String getQuestionB() {
        return questionB;
    }

    public void setQuestionB(String questionB) {
        this.questionB = questionB;
    }

    public String getQuestionC() {
        return questionC;
    }

    public void setQuestionC(String questionC) {
        this.questionC = questionC;
    }

    public String getQuestionD() {
        return questionD;
    }

    public void setQuestionD(String questionD) {
        this.questionD = questionD;
    }

    public String getCorrect() {
        return correct;
    }

    public void setCorrect(String correct) {
        this.correct = correct;
    }
}
