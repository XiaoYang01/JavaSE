package userSystem;

import util.MysqlConnect;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @Author:XiaoYang01
 * @Date: 2021/3/6 12:09 @Week: 星期六
 * Package: JavaSE
 */
public class QuestionsAdd extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取传参
        String title, questionA, questionB, questionC, questionD, correct;
        title = req.getParameter("title");
        questionA = req.getParameter("questionA");
        questionB = req.getParameter("questionB");
        questionC = req.getParameter("questionC");
        questionD = req.getParameter("questionD");
        correct = req.getParameter("correct");

        //对象创建
        Questions questions = new Questions(null, title, questionA, questionB, questionC, questionD, correct);

        //JDBC
        MysqlConnect connect = new MysqlConnect();

        //add
        int count = connect.questionsAdd(questions);

        if (count != 0) {
            req.setAttribute("add", "添加成功");
        } else {
            req.setAttribute("add", "添加失败");
        }
        req.getRequestDispatcher("/JSP/QuestionsAdd.jsp").forward(req, resp);
    }
}
