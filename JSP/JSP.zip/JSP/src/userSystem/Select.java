package userSystem;

import util.MysqlConnect;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.Map;

/**
 * @Author:XiaoYang01
 * @Date: 2021/3/5 18:43 @Week: 星期五
 * Package: JavaSE
 */
public class Select extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //JDBC
        MysqlConnect connect = new MysqlConnect();

        //查询
        Map map = connect.select();

        //装入请求对象中
        req.setAttribute("select",map);

        //传参jsp
        req.getRequestDispatcher("/JSP/Select.jsp").forward(req,resp);

    }
}
