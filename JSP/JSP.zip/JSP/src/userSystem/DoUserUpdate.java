package userSystem;

import util.MysqlConnect;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @Author:XiaoYang01
 * @Date: 2021/3/6 19:51 @Week: 星期六
 * Package: JavaSE
 */
public class DoUserUpdate extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取传参
        Integer id = Integer.valueOf(req.getParameter("id"));
        String userName = req.getParameter("userName");
        String userPassword = req.getParameter("userPassword");

        //DoUser对象
        DoUser doUser = new DoUser(id,userName,userPassword);

        //JDBC
        MysqlConnect connect = new MysqlConnect();

        //传参与判断
        int count = connect.doUpdate(doUser);
        if(count != 0){
            req.setAttribute("update","修改成功");
        }else{
            req.setAttribute("update","修改失败");
        }
        req.getRequestDispatcher("/JSP/DoUserUpdate.jsp").forward(req,resp);
    }
}
