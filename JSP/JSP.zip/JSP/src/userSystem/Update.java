package userSystem;

import util.MysqlConnect;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @Author:XiaoYang01
 * @Date: 2021/3/6 16:03 @Week: 星期六
 * Package: JavaSE
 */
public class Update extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取ID
        Integer id = Integer.valueOf(req.getParameter("id"));
        System.out.println(id);

        //JDBC
        MysqlConnect connect = new MysqlConnect();

        //传参
        Questions questions = connect.select(id);

        //判断
        if(questions != null){
            req.setAttribute("id",questions);
            req.getRequestDispatcher("/JSP/Update.jsp").forward(req,resp);
            return;
        }else{
            req.getRequestDispatcher("/error/404.html").forward(req,resp);
            return;
        }
    }
}
