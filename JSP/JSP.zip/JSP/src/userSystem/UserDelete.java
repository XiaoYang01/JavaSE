package userSystem;

import util.MysqlConnect;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @Author:XiaoYang01
 * @Date: 2021/3/6 15:40 @Week: 星期六
 * Package: JavaSE
 */
public class UserDelete extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取ID
        Integer id = Integer.valueOf(req.getParameter("id"));

        //JDBC
        MysqlConnect connect = new MysqlConnect();

        //传参
        int count = connect.userDelete(id);

        //判断
        if (count != 0) {
            req.setAttribute("delete", "删除成功");
        } else {
            req.setAttribute("delete", "删除失败");
        }
        req.getRequestDispatcher("/JSP/UserDelete.jsp").forward(req,resp);
    }
}
