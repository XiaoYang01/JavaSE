package util;

import userSystem.DoUser;
import userSystem.Questions;
import userSystem.User;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author:XiaoYang01
 * @Date: 2021/3/4 16:40 @Week: 星期四
 * Package: JavaSE
 */
public class MysqlConnect {
    JDBCMysql jdbcMysql = new JDBCMysql();

    //登录验证
    public boolean login(User user) {
        boolean flag = false;
        //sql
        String sql = "select userName,userPassword from t_user where userName=? and userPassword=?";
        PreparedStatement ps = jdbcMysql.getStatement(sql);
        //Resultset
        ResultSet rs = null;
        try {
            //占位，赋值
            ps.setString(1, user.getUserName());
            ps.setString(2, user.getUserPassword());
            rs = ps.executeQuery();
            while (rs.next()) {
                String name = rs.getString("userName");
                String pwd = rs.getString("userPassword");
                if (name != null && pwd != null) {
                    flag = true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //关闭流
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return flag;
    }

    //注册
    public int register(User user) {
        //定义返回值
        int count = 0;
        //sql
        String sql = "insert into t_user (userName,userPassword) value(?,?)";
        //添加到PrepareStatement
        PreparedStatement ps = jdbcMysql.getStatement(sql);
        //占位赋值
        try {
            ps.setString(1, user.getUserName());
            ps.setString(2, user.getUserPassword());
            //获取返回值
            count = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (ps != null) {
                try {
                    ps.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return count;
    }

    //查询
    public Map select() {
        //sql
        String sql = "select * from t_user";

        //传参
        PreparedStatement ps = jdbcMysql.getStatement(sql);

        //返回值
        ResultSet rs = null;

        //创建Map集合
        Map map = new HashMap();
        try {
            rs = ps.executeQuery();

            //遍历
            while (rs.next()) {
                Integer id = rs.getInt("id");
                String userName = rs.getString("userName");
                String userPassword = rs.getString("userPassword");

                //DoUser对象创建
                DoUser doUser = new DoUser(id, userName, userPassword);

                //doUser添加到Map中
                map.put(doUser, true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return map;
    }

    //查询重载
    public Questions select(int id) {
        //sql
        String sql = "select * from question where id = ?";

        //传参
        PreparedStatement ps = jdbcMysql.getStatement(sql);

        //返回值
        ResultSet rs = null;

        //Questions对象创建
        Questions questions = null;

        try {
            ps.setInt(1, id);
            rs = ps.executeQuery();
            //遍历
            while (rs.next()) {
                Integer isId = rs.getInt("id");
                String title = rs.getString("title");
                String questionA = rs.getString("questionA");
                String questionB = rs.getString("questionB");
                String questionC = rs.getString("questionC");
                String questionD = rs.getString("questionD");
                String correct = rs.getString("correct");
                //DoUser对象创建
                questions = new Questions(isId, title, questionA, questionB, questionC, questionD, correct);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return questions;
    }

    //UserId查询
    public DoUser userSelect(int id) {
        //sql
        String sql = "select * from t_user where id = ?";

        //PrepareStatement
        PreparedStatement ps = jdbcMysql.getStatement(sql);

        //ResulSet,DoUser
        ResultSet rs = null;
        DoUser doUser = null;
        //传参
        try {
            ps.setInt(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                Integer isId = rs.getInt("id");
                String userName = rs.getString("userName");
                String userPassword = rs.getString("userPassword");

                //Douser对象
                doUser = new DoUser(isId, userName, userPassword);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (ps != null) {
                try {
                    ps.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return doUser;
    }

    //UserID修改
    public int doUpdate(DoUser doUser){
        //定义返回值
        int count = 0;

        //sql
        String sql = "update t_user set userName = ? , userPassword = ? where id = ?";

        //PrepareStatement
        PreparedStatement ps = jdbcMysql.getStatement(sql);

        //赋值
        try {
            ps.setString(1,doUser.getUserName());
            ps.setString(2,doUser.getUserPassword());
            ps.setInt(3,doUser.getId());

            //返回值
            count = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }

    //试题添加
    public int questionsAdd(Questions questions) {
        //定义返回值
        int count = 0;
        //sql
        String sql = "insert into question (title,questionA,questionB,questionC,questionD,correct) value(?,?,?,?,?,?)";
        //添加到PrepareStatement
        PreparedStatement ps = jdbcMysql.getStatement(sql);
        //占位赋值
        try {
            ps.setString(1, questions.getTitle());
            ps.setString(2, questions.getQuestionA());
            ps.setString(3, questions.getQuestionB());
            ps.setString(4, questions.getQuestionC());
            ps.setString(5, questions.getQuestionD());
            ps.setString(6, questions.getCorrect());
            //获取返回值
            count = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (ps != null) {
                try {
                    ps.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return count;
    }

    //试题查询
    public Map questionSelect() {
        //sql
        String sql = "select * from question";

        //PreparedStatement
        PreparedStatement ps = jdbcMysql.getStatement(sql);

        //ResulSet
        ResultSet rs = null;

        //Map集合
        Map map = new HashMap();

        try {
            rs = ps.executeQuery();
            //遍历
            while (rs.next()) {
                int id = rs.getInt("id");
                String title = rs.getString("title");
                String questionA = rs.getString("questionA");
                String questionB = rs.getString("questionB");
                String questionC = rs.getString("questionC");
                String questionD = rs.getString("questionD");
                String correct = rs.getString("correct");
                Questions questions = new Questions(id, title, questionA, questionB, questionC, questionD, correct);
                map.put(questions, true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (ps != null) {
                try {
                    ps.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return map;
    }

    //用户删除
    public int userDelete(int id) {
        //定义返回值
        int count = 0;
        //sql
        String sql = "delete from t_user where id = ?";
        //添加到PrepareStatement
        PreparedStatement ps = jdbcMysql.getStatement(sql);
        //占位赋值
        try {
            ps.setInt(1, id);
            //获取返回值
            count = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (ps != null) {
                try {
                    ps.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return count;
    }

    //试题修改
    public int doUpdate(Questions questions) {
        ///定义返回值
        int count = 0;

        //sql
        String sql = "update question set title=?,questionA=?,questionB=?,questionC=?,questionD=?,correct=? where id = ?";

        //PrepareStatement
        PreparedStatement ps = jdbcMysql.getStatement(sql);
        try {
            ps.setString(1, questions.getTitle());
            ps.setString(2, questions.getQuestionA());
            ps.setString(3, questions.getQuestionB());
            ps.setString(4, questions.getQuestionC());
            ps.setString(5, questions.getQuestionD());
            ps.setString(6, questions.getCorrect());
            ps.setInt(7, questions.getId());
            count = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }

    //试题删除
    public int QuestionsDelete(int id) {
        //定义返回值
        int count = 0;

        //sql
        String sql = "delete from question where id = ?";

        //PrepareStatement
        PreparedStatement ps = jdbcMysql.getStatement(sql);

        //传参
        try {
            ps.setInt(1, id);
            count = ps.executeUpdate(); //接受返回值
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }
}
