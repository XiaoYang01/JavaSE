package util;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Map;

/**
 * @Author:XiaoYang01
 * @Date: 2021/2/18 21:39 @Week: 星期四
 * Package: JavaSE
 */
public class JDBCMysql {
    //构造器
    public JDBCMysql() {
    }

    PreparedStatement ps = null;
    Connection con = null;

    //注册驱动
    static {
        try {
            Class driver = Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    /*//getCon重载
    public Connection getCon(HttpServletRequest req) {
        //通过请求对象，获取全局作用域对象
        ServletContext servletContext = req.getServletContext();
        //获取map集合
        Map map = (Map) servletContext.getAttribute("key01");
        //循环遍历map
        Iterator it = map.keySet().iterator();
        while (it.hasNext()) {
            //遍历出来的数据。转换成Connection
            con = (Connection) it.next();
            //获取value
            boolean flag = (boolean) map.get(con);
            if (flag == true) {
                map.put(con, false);
                break;
            }
        }
        return con;
    }

    //PrepareStatement重载
    public PreparedStatement getStatement(String sql, HttpServletRequest req) {
        try {
            ps = getCon(req).prepareStatement(sql);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return ps;
    }

    //close重载
    public void close(HttpServletRequest req) {
        if (ps != null) {
            try {
                ps.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        //回收Connection
        ServletContext context = req.getServletContext();
        //获取使用完毕的key,重新装进Map
        Map map = (Map) context.getAttribute("key01");
        map.put(con, true);
    }*/

    //连接mysql
    public Connection getCon() {
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/timejya", "root", "root");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return con;
    }

    public PreparedStatement getStatement(String sql) {
        try {
            ps = getCon().prepareStatement(sql);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return ps;
    }
}
