//页面加载完，执行该程序
window.onload = function (){
    //获取left下的标签ID
    var userAdd = document.getElementById("userAdd");
    var userSelect = document.getElementById("userSelect");
    var questionsAdd = document.getElementById("questionsAdd");
    var questionsSelect = document.getElementById("questionsSelect");

    /*
        次方法是用户点击事件，注册用户
     */
    userAdd.onclick = function () {
        //获取，iframe,页面跳转
        var t_Iframe = document.getElementById("t_Iframe");
        t_Iframe.src = "/myWeb/html/LoginRegister.html";
    }

    /*
        次方法是用户点击事件，查询用户
     */
    userSelect.onclick = function () {
        //获取，iframe,页面跳转
        var t_Iframe = document.getElementById("t_Iframe");
        t_Iframe.src = "/myWeb/select";
    }

    /*
        次方法是用户点击事件：试题添加
     */
    questionsAdd.onclick = function () {
        //获取，iframe,页面跳转
        var t_Iframe = document.getElementById("t_Iframe");
        t_Iframe.src = "/myWeb/html/QuestionsAdd.html"
    }

    /*
        次方法是用户点击事件：试题查询
     */
    questionsSelect.onclick = function () {
        //获取，iframe,页面跳转
        var t_Iframe = document.getElementById("t_Iframe");
        t_Iframe.src = "/myWeb/questionSelect";
    }
}