window.onload = function (){
    var register = document.getElementById("register");
    register.onclick = function(){
        window.location.href = "/myWeb/html/LoginRegister.html";
    }
}